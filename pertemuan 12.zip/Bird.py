from Animal import Animal

class Bird(Animal):

#KONSTRUKTOR PROPERTI
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, paruh):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna = warna
        self. paruh = paruh

#METHOD INFORMASI
    def info_bird(self):
        super().info_animal()
        print("Warna\t\t\t: ", self.warna,
         "\nJenis Paruh\t\t: ", self.paruh)


#CETAK
print()
bird = Bird("Elang", "Daging", "Hutan Hujan Tropis", "Bertelur", "Coklat", "Bengkok dan Lancip")
print("============================================")
print('## Info Bird ##')
bird.info_bird()

print()
bird = Bird("Rajawali", "Mamalia Kecil", "Hutan Gugur", "Bertelur", "Coklat", "Bengkok dan Lancip")
print("============================================")
print('## Info Bird ##')
bird.info_bird()

print()
bird = Bird("Kasuari", "Buah-Buahan", "Hutan Dataran Rendah", "Bertelur", "Dominan Hitam", "Bengkok dan Lancip")
print("============================================")
print('## Info Bird ##')
bird.info_bird()



