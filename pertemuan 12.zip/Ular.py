from Animal import Animal

class Snake(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, bernapas, habitat):
        super().__init__(nama, makanan, hidup, berkembang_biak,)
        self.bernapas = bernapas
        self.habitat = habitat

    def info_snake(self):
        super().info_animal()
        print("Bernapas menggunakan\t: ",
        self.bernapas, 
        "\nHabitat Di\t\t: ", self.habitat)



print()
snake = Snake("Anaconda", "Daging", "Hutan", "Bertelur", "Paru-Paru", "Wilayah Tropis")
print("============================================")
print("## Info Snake ##")
snake.info_snake()

print()
snake = Snake("Piton", "Daging", "Hutan", "Bertelur", "Paru-Paru", "Hutan Hujan")
print("============================================")
print("## Info Snake ##")
snake.info_snake()

print()
snake = Snake("Sanca", "Mamalia Kecil", "Hutan Hujan Tropis", "Bertelur", "Paru-Paru", "Semak Blukar")
print("============================================")
print("## Info Snake ##")
snake.info_snake()