from Animal import Animal

class Fish(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, bernapas, habitat):
        super().__init__(nama, makanan, hidup, berkembang_biak,)
        self.bernapas = bernapas
        self.habitat = habitat

    def info_fish(self):
        super().info_animal()
        print("Bernapas menggunakan\t: ",
        self.bernapas, 
        "\nHabitat Di\t\t: ", self.habitat)




print()
fish = Fish("Ikan Hiu", "Daging", "Laut", "Melahirkan", "Paru-Paru", "Air Asin")
print("============================================")
print("## Info Fish ##")
fish.info_fish()

print()
fish = Fish("Lumba-Lumba", "Ikan Kecil", "Laut", "Melahirkan", "Paru-Paru", "Lautan atau Samudra")
print("============================================")
print("## Info Fish ##")
fish.info_fish()

print()
fish = Fish("Ikan Nemo", "Alga", "Terumbu Karang", "Bertelur", "Insang", "Perairan Hangat")
print("============================================")
print("## Info Fish ##")
fish.info_fish()